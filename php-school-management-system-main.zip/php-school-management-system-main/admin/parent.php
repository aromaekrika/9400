<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
</head>
<body style="font-family: Arial, sans-serif; background-color: #f3e5f5; padding: 0; margin: 0; color: #6a1b9a;">
<div style="width: 200px; background-color: #2e3a4b; height: 100vh; position: fixed; color: white;">
  <div style="padding: 20px; text-align: center;">
    <h3 style="color: #fff;">Joe Goldberg</h3>
  </div>
  <ul style="list-style-type: none; padding: 0;">
    <li style="padding: 10px;"><a href="#" style="color: white; text-decoration: none;">Dashboard</a></li>
    <li style="padding: 10px;"><a href="#" style="color: white; text-decoration: none;">Admin</a></li>
    <li style="padding: 10px;"><a href="#" style="color: white; text-decoration: none;">Student</a></li>
    <li style="padding: 10px;"><a href="C:\xampp\htdocs\myphp\parent\dashboard.php" style="color: white; text-decoration: none;">Parents</a></li>
    <!-- Add more navigation items -->
  </ul>
</div>
<div style="background-color: #fff; padding: 10px 20px; margin-left: 200px;">
  <!-- <input type="text" placeholder="Search here..." style="width: 200px; padding: 5px;"> -->
  <span style="float: right;">
    <a href="#" style="margin-right: 20px;">Notifications</a>
    <a href="#">Profile</a>
  </span>
</div>
<div style="margin-left: 200px; padding: 20px;">
  <!-- My Children Section -->
  <div style="display: flex; justify-content: space-between;">
    <div style="width: 48%; background-color: white; padding: 20px; box-shadow: 0px 0px 5px rgba(0,0,0,0.1);">
      <h4>My Children_01</h4>
      <p>Name: emma</p>
      <p>Gender: male</p>
      <p>Roll: #2901</p>
      <!-- More child details -->
    </div>
    <!-- <div style="width: 48%; background-color: white; padding: 20px; box-shadow: 0px 0px 5px rgba(0,0,0,0.1);">
      <h4>My Children_02</h4>
      <p>Name: Mark Willy</p>
      <p>Gender: Male</p>
      <p>Roll: #2959</p> -->
      <!-- More child details -->
    </div>
  </div>

  <!-- Widgets Section -->
  <div style="display: flex; justify-content: space-between; margin-top: 20px;">
    <div style="width: 24%; background-color: #e91e63; color: white; padding: 20px;">
      <h4>1,500</h4>
      <p>Due Fees</p>
    </div>
    <div style="width: 24%; background-color: #3f51b5; color: white; padding: 20px;">
      <h4>08</h4>
      <p>Result Published</p>
    </div>
    <div style="width: 24%; background-color: #4caf50; color: white; padding: 20px;">
      <h4>10,000</h4>
      <p>Total Expenses</p>
    </div>
    <div style="width: 24%; background-color: #ff9800; color: white; padding: 20px;">
      <h4>08</h4>
      <p>Upcoming Exams</p>
    </div>
  </div>

  <!-- Notice Board -->
  <div style="margin-top: 20px;">
    <h4>Notice Board</h4>
    <div style="background-color: white; padding: 20px; box-shadow: 0px 0px 5px rgba(0,0,0,0.1);">
      <p>16 july, 2024</p>
    
      <!-- More notices -->
    </div>
  </div>

  <!-- All Expenses -->
  <div style="margin-top: 20px;">
    <h4>All Expenses</h4>
    <table style="width: 100%; border-collapse: collapse;">
      <thead>
        <tr>
          <th>ID No</th>
          <th>Expense Type</th>
          <th>Amount</th>
          <th>Status</th>
          <th>Email</th>
          <th>Date</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>#3055</td>
          <td>Salary</td>
          <td>$00.00</td>
          <td style="color: red;">Due</td>
          <td>bossekrika@gmail.com</td>
          <td>20/06/2024</td>
        </tr>
        <!-- More expense rows -->
      </tbody>
    </table>
  </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>