<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
</head>
<body style="font-family: Arial, sans-serif; background-color: #f3e5f5; padding: 0; margin: 0; color: #6a1b9a;">
<div style="width: 200px; background-color: #2e3a4b; height: 100vh; position: fixed; color: white;">
  <div style="padding: 20px; text-align: center;">
    <h3 style="color: #fff;">SCHOOL MANAGEMENT SYSTEM</h3>
  </div>
  <ul style="list-style-type: none; padding: 0;">
    <li style="padding: 10px;"><a href="#" style="color: white; text-decoration: none;">Dashboard</a></li>
    <li style="padding: 10px;"><a href="attendance.php" style="color: white; text-decoration: none;">Attendance </a></li>
    <!-- <li style="padding: 10px;"><a href="assignment.php" style="color: white; text-decoration: none;">Assignment</a></li> -->
    <li style="padding: 10px;"><a href="parent.php" style="color: white; text-decoration: none;">Parents</a></li>
    <!-- Add more navigation items -->

    
  </ul>
</div>

<div style="background-color: #6a1b9a;  text-align: center; color: white; margin-left: 200px; padding: 20px;">
        <h1>Admin Dashboard</h1>
        <p>Welcome, <?php echo $_SESSION['username']; ?>!</p>
    </div>
    <div  style=" margin-left: 200px; padding: 20px; ">
        <h2 style="color: #6a1b9a;">Manage Users</h2>
        <div style="display:flex;">
        <div style="background-color: #b39ddb; width: 200px; padding: 20px; border-radius: 10px; text-align: center; margin-right:10px; padding:80px;"><a href="students.php" style="color: #6a1b9a;">Manage Students</a></div>
            <!-- <li><a href="teachers.php" style="color: #6a1b9a;">Manage Teachers</a></li> --> <br>
        <div style="background-color: #b39ddb; width: 200px; padding: 80px; border-radius: 10px; text-align: center;"><a href="courses.php" style="color: #6a1b9a;">Manage course</a></div>
        
        </div>
            
        <h2 style="color: #6a1b9a;">Results</h2>
        
            <a href="upload_results.php" style="color: #6a1b9a;">Upload Results</a>
        
        <!-- <a href="login.php" style="display: block; margin-top: 20px; color: #6a1b9a;">Logout</a> -->
    </div>



    <div style="margin-left: 220px; padding: 20px;">
    <div style="display: flex; justify-content: space-around; margin-bottom: 20px;">
        <!-- Card 1 -->
        <!-- <div style="background-color: #d1c4e9; width: 30%; padding: 20px; border-radius: 10px; text-align: center;">
            <h3 style="color: #6a1b9a;">Total Students</h3>
            <p style="font-size: 24px;">1</p>
        </div> -->
        <!-- Card 2 -->
        <!-- <div style="background-color: #b39ddb; width: 30%; padding: 20px; border-radius: 10px; text-align: center;">
            <h3 style="color: #6a1b9a;">Total Teachers</h3>
            <p style="font-size: 24px;">100</p>
        </div> -->
        <!-- Card 3 -->
        <!-- <div style="background-color: #9575cd; width: 30%; padding: 20px; border-radius: 10px; text-align: center;">
            <h3 style="color: #6a1b9a;">Pending Fees</h3>
            <p style="font-size: 24px;"></p>
        </div> -->
    </div>
</div>


<div style="margin-left: 220px; padding: 20px;">
    <h2>Dashboard Notifications</h2>
    <div style="background-color: #ffeb3b; padding: 15px; border-radius: 5px; margin-bottom: 10px;">
        <p><strong>New Update:</strong> Results for the 2023 Semester are now live!</p>
    </div>
    <div style="background-color: #ff7043; padding: 15px; border-radius: 5px;">
        <p><strong>Reminder:</strong> Fee Payment deadline is approaching!</p>
    </div>
<br>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
  google.charts.load('current', {'packages':['corechart']});
  google.charts.setOnLoadCallback(drawChart);

  function drawChart() {
    var data = google.visualization.arrayToDataTable([
      ['Subject', 'Marks'],
      ['Math',     85],
      ['English',  78],
      ['Science',  92],
      ['History',  65],
      ['Geography', 75]
    ]);

    var options = {
      title: 'Student Performance',
      pieHole: 0.4,
    };

    var chart = new google.visualization.PieChart(document.getElementById('donutchart'));
    chart.draw(data, options);
  }
</script>

<div id="donutchart" style="width: 900px; height: 500px;"></div>

</div>






    <div style="margin-left: 220px; padding: 20px;">
    <h2>School Calendar</h2>
    <iframe src="https://calendar.google.com/calendar/embed?src=your_calendar_id&ctz=America/New_York" 
    style="border: 0" width="800" height="600" frameborder="0" scrolling="no"></iframe>
</div>




<div style="background-color: #6a1b9a; color: white; text-align: center; padding: 15px; position: fixed; bottom: 0; width: 100%;">
    <p style="margin: 0;">&copy; <?php echo date('Y'); ?> School Management System. All Rights Reserved. | <a href="contact.php" style="color: white; text-decoration: none;">Contact Us</a> | <a href="terms.php" style="color: white; text-decoration: none;">Terms & Conditions</a></p>
</div>
    
    
</body>
</html>
