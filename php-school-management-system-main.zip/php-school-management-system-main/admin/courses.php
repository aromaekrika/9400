<?php
session_start();
include('../db.php');

if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}

// Add course logic
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $course_name = $_POST['course_name'];
    $course_code = $_POST['course_code'];
    $teacher_id = $_POST['teacher_id'];

    $sql = "INSERT INTO courses (course_name, course_code, teacher_id) VALUES ('$course_name', '$course_code', '$teacher_id')";
    if ($conn->query($sql) === TRUE) {
        echo "New course added successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Courses</title>
    <link rel="stylesheet" type="text/css" href="../assets/css/style.css">
</head>
<body>
    <h1>Manage Courses</h1>
    <form method="post" action="">
        <label>Course Name:</label>
        <input type="text" name="course_name" required>
        <label>Course Code:</label>
        <input type="text" name="course_code" required>
        <label>Teacher:</label>
        <select name="teacher_id" required>
            <option value="">Select Teacher</option>
            <?php
            $sql = "SELECT * FROM teachers";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<option value='{$row['id']}'>{$row['name']}</option>";
                }
            }
            ?>
        </select>
        <button type="submit">Add Course</button>
    </form>

    <h2>Course List</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Course Name</th>
            <th>Course Code</th>
            <th>Teacher</th>
        </tr>
        <?php
        $sql = "SELECT courses.id, courses.course_name, courses.course_code, teachers.name AS teacher_name FROM courses LEFT JOIN teachers ON courses.teacher_id = teachers.id";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['course_name']}</td>
                    <td>{$row['course_code']}</td>
                    <td>{$row['teacher_name']}</td>
                </tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No courses found</td></tr>";
        }
        ?>
    </table>
    <a href="dashboard.php">Back to Dashboard</a>
</body>
</html>
