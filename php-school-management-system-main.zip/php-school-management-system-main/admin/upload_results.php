<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Results</title>
</head>
<body style="font-family: Arial, sans-serif; background-color: #f3e5f5; padding: 0; margin: 0; color: #6a1b9a;">
    <div style="background-color: #6a1b9a; padding: 20px; text-align: center; color: white;">
        <h1>Upload Results</h1>
        <p>Welcome, <?php echo $_SESSION['username']; ?>!</p>
    </div>
    <div style="padding: 20px;">
        <h2 style="color: #6a1b9a;">Upload Results</h2>
        <form action="upload_results.php" method="post" enctype="multipart/form-data">
            <label for="file" style="color: #6a1b9a;">Select file to upload:</label>
            <input type="file" name="file" id="file" style="margin-bottom: 15px;">
            <input type="submit" value="Upload Results" name="submit" style="padding: 10px; background-color: #6a1b9a; color: white; border: none; border-radius: 4px; cursor: pointer;">
        </form>
        <!-- Add PHP code to handle file upload and process results -->
        <a href="dashboard.php" style="display: block; margin-top: 20px; color: #6a1b9a;">Back to Dashboard</a>
    </div>
</body>
</html>
