<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}
?>

<div style="margin-left: 220px; padding: 20px;">
    <h2>Mark Attendance</h2>
    <form action="mark_attendance.php" method="post">
        <label for="student_id">Student ID:</label>
        <input type="text" name="student_id" required><br><br>
        <label for="status">Attendance Status:</label>
        <select name="status">
            <option value="Present">Present</option>
            <option value="Absent">Absent</option>
        </select><br><br>
        <input type="submit" value="Submit" style="background-color: #6a1b9a; color: white; padding: 10px;">
    </form>
</div>
