<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}
?>

<div style="margin-left: 220px; padding: 20px;">
    <h2>Upload Assignments</h2>
    <form action="upload_assignment.php" method="post" enctype="multipart/form-data">
        <label for="assignment">Select Assignment to Upload:</label><br>
        <input type="file" name="assignment" id="assignment"><br><br>
        <input type="submit" value="Upload Assignment" style="background-color: #6a1b9a; color: white; padding: 10px;">
    </form>
</div>
