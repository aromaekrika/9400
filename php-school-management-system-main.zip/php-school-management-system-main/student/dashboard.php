<?php
session_start();
if ($_SESSION['role'] != 'student') {
    header("Location: login.php");
    exit();
}
?>

<!-- Header Section -->
<div style="background-color: #6a1b9a; padding: 20px; color: white; text-align: center;">
    <h2>Welcome to Your Student Dashboard, <?php echo $_SESSION['username']; ?>!</h2>
</div>

<!-- Main Content Section -->
<div style="margin: 20px;">

    <!-- Student Profile Card -->
    <div style="display: flex; justify-content: space-between;">
        <div style="background-color: #9575cd; padding: 20px; width: 30%; border-radius: 10px; text-align: center; color: white;">
            <h3>Profile Overview</h3>
            <!-- Default Profile Picture -->
            <img src="https://www.w3schools.com/w3images/avatar2.png" alt="Profile Picture" 
                 style="border-radius: 50%; width: 100px; height: 100px;">
            <p><strong>Name:</strong> <?php echo $_SESSION['username']; ?></p>
            <p><strong>Class:</strong> 10</p>
            <p><strong>Section:</strong> B</p>
        </div>


        <!-- Attendance Overview -->
        <div style="background-color: #b39ddb; padding: 20px; width: 30%; border-radius: 10px; text-align: center; color: white;">
            <h3>Attendance</h3>
            <p style="font-size: 24px;">90%</p>
            <p>You're doing great! Keep it up!</p>
        </div>

        <!-- Performance Overview -->
        <div style="background-color: #d1c4e9; padding: 20px; width: 30%; border-radius: 10px; text-align: center; color: white;">
            <h3>Performance Overview</h3>
            <p style="font-size: 24px;">Average Grade: B+</p>
            <p>Subjects with upcoming exams: Math, Science</p>
        </div>
    </div>


    <div style="background-color: #9575cd; padding: 20px; margin-top: 20px; border-radius: 10px; color: white;">
    <h3>Submit Your Assignment</h3>
    <form action="submit_assignment.php" method="post" enctype="multipart/form-data">
        <label for="subject">Select Subject:</label><br>
        <select name="subject" id="subject" style="padding: 5px; margin-bottom: 10px; width: 100%;">
            <option value="Math">Math</option>
            <option value="Science">Science</option>
            <option value="History">History</option>
        </select><br>
        
        <label for="file">Choose Assignment File:</label><br>
        <input type="file" name="file" id="file" required style="margin-bottom: 10px;"><br>
        
        <input type="submit" value="Submit" style="background-color: #6a1b9a; color: white; padding: 10px; border: none; border-radius: 5px;">
    </form>
</div>



    <!-- Important Announcements -->
    <div style="background-color: #6a1b9a; padding: 20px; margin-top: 20px; border-radius: 10px; color: white;">
        <h3>Announcements</h3>
        <p>📢 Midterm exams start next week. Please make sure you're prepared.</p>
        <p>📢 Homework submission deadline for Math and Science is tomorrow.</p>
    </div>

    <!-- Assignments and Resources Section -->
    <div style="display: flex; justify-content: space-between; margin-top: 20px;">
        <!-- Assignments -->
        <div style="background-color: #9575cd; padding: 20px; width: 48%; border-radius: 10px; color: white;">
            <h3>Assignments</h3>
            <ul style="list-style-type: none; padding: 0;">
                <li>📄 <a href="assignment1.pdf" style="color: white;">Math Homework</a> - Due: 20th Sep</li>
                <li>📄 <a href="assignment2.pdf" style="color: white;">Science Project</a> - Due: 25th Sep</li>
                <li>📄 <a href="assignment3.pdf" style="color: white;">History Essay</a> - Due: 28th Sep</li>
            </ul>
        </div>

        <!-- Resources -->
        <div style="background-color: #b39ddb; padding: 20px; width: 48%; border-radius: 10px; color: white;">
            <h3>Useful Resources</h3>
            <ul style="list-style-type: none; padding: 0;">
                <li>📘 <a href="math_resources.php" style="color: white;">Math Study Materials</a></li>
                <li>📘 <a href="science_resources.php" style="color: white;">Science Lab Guides</a></li>
                <li>📘 <a href="history_resources.php" style="color: white;">History Exam Prep</a></li>
            </ul>
        </div>
    </div>


    <div style="margin-top: 20px;">
    <h3 style="color: #6a1b9a; text-align: center;">Upcoming Events & Exams</h3>
    <iframe src="https://calendar.google.com/calendar/embed?src=your_google_calendar_id&ctz=Your_Timezone" 
        style="border: 0" width="100%" height="600px" frameborder="0" scrolling="no"></iframe>
</div>

    <!-- Footer -->
    <div style="background-color: #6a1b9a; color: white; text-align: center; padding: 15px; margin-top: 20px;">
        <p style="margin: 0;">&copy; <?php echo date('Y'); ?> School Management System. All Rights Reserved.</p>
    </div>
</div>

