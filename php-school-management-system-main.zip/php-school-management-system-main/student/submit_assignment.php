<?php
session_start();
if ($_SESSION['role'] != 'student') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $subject = $_POST['subject'];
    $file = $_FILES['file'];
    
    // Directory where the file will be saved
    $upload_dir = 'uploads/assignments/';
    
    // Get file info
    $file_name = $file['name'];
    $file_tmp = $file['tmp_name'];
    $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
    
    // Create a unique file name
    $new_file_name = $_SESSION['username'] . '_' . time() . '.' . $file_ext;
    
    // Save the file
    if (move_uploaded_file($file_tmp, $upload_dir . $new_file_name)) {
        echo "<p>Assignment successfully submitted!</p>";
    } else {
        echo "<p>There was an error uploading your file. Please try again.</p>";
    }
}
?>
