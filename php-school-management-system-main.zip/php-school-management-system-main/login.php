<?php
session_start();
include('db.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $role = $_POST['role'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? AND role = ?");
    $stmt->bind_param("ss", $username, $role);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $_SESSION['username'] = $username;
        $_SESSION['role'] = $row['role'];

        if ($row['role'] == 'admin') {
            header("Location: admin/dashboard.php");
        } else if ($row['role'] == 'student') {
            header("Location: student/dashboard.php");
        } else {
            header("Location: index.php");
        }
        exit();
    } else {
        $error = "Invalid username or role.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body style="display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; font-family: Arial, sans-serif; background-color: #f3e5f5;">

    <div style="background-color: white; padding: 40px; border-radius: 8px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); width: 300px; text-align: center;">
        <h1 style="color: #6a1b9a;">School Management System</h1>
        <form method="POST" action="login.php">
            <label for="username" style="display: block; margin-bottom: 5px; text-align: left; color: #6a1b9a;">Username:</label>
            <input type="text" id="username" name="username" required style="self-align:center; width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px;">

            <label for="password" style="display: block; margin-bottom: 5px; text-align: left; color: #6a1b9a;">Password:</label>
            <input type="password" id="password" name="password" required style="width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px;">


            <label for="role" style="display: block; margin-bottom: 5px; text-align: left; color: #6a1b9a;">Role:</label>
            <select id="role" name="role" required style="width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px;">
                <option value="admin">Admin</option>
                <option value="student">Student</option>
            </select>

            <button type="submit" style="width: 100%; padding: 10px; background-color: #6a1b9a; color: white; border: none; border-radius: 4px; cursor: pointer;">Login</button>
        </form>

        <?php
        if (isset($error)) {
            echo "<p style='color: red; margin-bottom: 15px;'>$error</p>";
        }
        ?>

    </div>
</body>
</html>
